const http = require('http');

const server = http.createServer((req, res) => {
    res.writeHead(200, {
        'Content-Type': 'text/plain'
    });

    res.end(`Hello from container!\nRequest from: ${req.connection.remoteAddress}\n`);
});

const port = process.env.PORT || 8080;

server.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on port ${port}`);
});