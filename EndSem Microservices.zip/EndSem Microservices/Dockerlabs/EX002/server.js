var http = require("http");

const PORT = process.env.PORT || 8888;

http
  .createServer((request, response) => {
    response.end("Server is running.!! You asked for: " + request.url);
  })
  .listen(PORT, () => {
    console.log("Server listening on: http://localhost:%s", PORT);
  })


