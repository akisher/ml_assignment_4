
import time
import requests

SERVER_URL = "http://server:6006/api/message"

while True:
    try:
        response = requests.get(SERVER_URL, timeout=3)
        response.raise_for_status()

        print("Response from Flask server:", flush=True)
        print(response.json(), flush=True)

    except requests.RequestException as error:
        print(f"Could not connect to server: {error}", flush=True)

    time.sleep(5)
