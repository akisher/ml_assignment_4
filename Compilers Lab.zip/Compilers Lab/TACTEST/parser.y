%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *ch);
int yylex(void);
int label=1;
int temp=1;
char *newtemp(){
    char buffer[20];
    sprintf(buffer,"t%d",temp++);
    return strdup(buffer);
}
char *newlabel(){
    char buffer[20];
    sprintf(buffer,"L%d",label);
    return strdup(buffer);
}

%}

%union{
    char *str;
}

%token <str> ID NUM
%token WHILE
%token LT ASSIGN MUL ADD
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON INVALID

%type <str> condition expr

%left ADD
%left MUL

%%

grammar:
            loop
        ;

loop:
        WHILE LPAREN    
        {
            printf("Label%d:\n",label);
        }
        condition RPAREN 
        {
            printf("if False %s goto %d\n",$4,label+1);
        }
        LBRACE statements RBRACE
        {
            printf("GOTO L%d:\n",label);
            printf("L%d:\n",label+1);
            label+=2;
        }
        ;

condition:
            expr LT expr
            {
                char *temp=newtemp();
                printf("%s=%s<%s\n",temp,$1,$3);
                $$=temp;
            }
        ;

statements:
            statement
        |   statements statement
        ;

statement:
            ID ASSIGN expr SEMICOLON
            {
                printf("%s=%s\n",$1,$3);
            }
            ;

expr:
            ID {
                $$=$1;
            }
        |
            NUM {
                $$=$1;
            }
        |   expr ADD expr {
                char *temp=newtemp();
                printf("%s=%s+%s\n",temp,$1,$3);
                $$=temp;
            }
        |   expr MUL expr {
            char *temp=newtemp();
            printf("%s=%s*%s\n",temp,$1,$3);
            $$=temp;
            }
        | LPAREN expr RPAREN {
            $$=$2;
        }
        ;

%%


void yyerror(const char *ch){
    printf("Error\n");
}
int main(){
    yyparse();
    return 0;
}

void optimizedTAC(){
    printf("\n Optimized TAC:\n");
    printf("t1=n*4\n");
    printf("t3=16*5\n");
    printf("L1:\n");
    printf("t2=m<t1\n");
    printf("IfFalse t2 goto L2\n");
    printf("r=t3\n");
    printf("t4=x*y\n");
    printf("t5=t4+z\n");
    printf("s=t5\n");
    printf("t6=m+s\n");
    printf("t=t6\n");
    printf("goto L1\n");
    printf("L2:\n");
}
void targetCode()
{
    printf("\nTARGET CODE:\n");

    /* t1 = n * 4 */
    printf("MOV R1, n\n");
    printf("MUL R1, 4\n");
    printf("MOV t1, R1\n");

    /* t3 = 16 * 5 */
    printf("MOV R1, 16\n");
    printf("MUL R1, 5\n");
    printf("MOV t3, R1\n");

    /* Loop condition: m < t1 */
    printf("L1:\n");
    printf("CMP m, t1\n");
    printf("JGE L2\n");

    /* r = t3 */
    printf("MOV r, t3\n");

    /* t4 = x * y */
    printf("MOV R1, x\n");
    printf("MUL R1, y\n");
    printf("MOV t4, R1\n");

    /* t5 = t4 + z */
    printf("MOV R1, t4\n");
    printf("ADD R1, z\n");
    printf("MOV t5, R1\n");

    /* s = t5 */
    printf("MOV s, t5\n");

    /* t6 = m + s */
    printf("MOV R1, m\n");
    printf("ADD R1, s\n");
    printf("MOV t6, R1\n");

    /* t = t6 */
    printf("MOV t, t6\n");

    /* Repeat loop */
    printf("JMP L1\n");
    printf("L2:\n");
}