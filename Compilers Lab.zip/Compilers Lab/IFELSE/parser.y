%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void yyerror(const char *ch);
int yylex(void);

int label=1;
int temp=1;

char *newtemp(){
    char buffer[20];
    sprintf(buffer,"t%d",temp++);
    return strdup(buffer);
}

char *newlabel(){
    char buffer[20];
    sprintf(buffer,"L%d",label++);
    return strdup(buffer);
}
%}

%union{
    char *str;
}

%token <str> ID NUM
%token IF ELSE
%token LT ASSIGN MUL ADD
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON INVALID

%type <str> condition expr

%left ADD
%left MUL

%%



program:    
        if_else
        ;
if_else:

        IF LPAREN condition RPAREN
        {
            printf("if false %s goto %d\n",$3,label);
        }
        LBRACE statements RBRACE
        {
            printf("goto L%d\n",label+1);
            printf("L%d\n",label);
        }
        ELSE LBRACE statements RBRACE
        {
            printf("L%d:\n",label+1);
        }
    ;

condition:
        expr LT expr
        {   
            char *t=newtemp();
            printf("%s=%s<%s\n",t,$1,$3);
            $$=t;
        }
        ;
statements:
        statement
        | statements statement
        ;
statement:
        ID ASSIGN expr SEMICOLON
        {
            printf("%s=%s\n",$1,$3);
        }
        ;

expr:
        ID {
            $$=$1;
        }
        |
        NUM {
            $$=$1;
        }
        |
        expr ADD expr {
            char *t=newtemp();
            printf("%s=%s+%s\n",t,$1,$3);
            $$=t;
        }
        |
        expr MUL expr{
            char *t=newtemp();
            printf("%s=%s*%s\n",t,$1,$3);
            $$=t;
        }
        |
        LPAREN expr RPAREN {
            $$=$2;
        }
        ;
%%



void yyerror(const char *ch){
    printf("error");
}
int main(){
    yyparse();
    return 0;
}