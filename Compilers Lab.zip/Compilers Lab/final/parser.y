%{
#include <stdio.h>
#include <stdlib.h>

int yylex(void);
void yyerror(const char *ch);
%}

%token WHILE ID NUM LT ASSIGN MUL ADD
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON INVALID

%left ADD 
%left MUL

%%

program:
        WHILE LPAREN condition RPAREN
        LBRACE statements RBRACE
        {
            printf("Syntax is correct.\n");
        }
        ;

condition:
            expression LT expression
        ;

statements:
            statement
        |   statements statement
        ;
statement:
            ID ASSIGN expression SEMICOLON
        ;
expression:
            ID
        |   NUM
        |   expression ADD expression
        |   expression MUL expression
        |   LPAREN expression RPAREN
        ;


%%

void yyerror(const char *ch){
    fprintf(stderr, "Syntax error: %s\n", ch);

}
int main(){
    yyparse();
    return 0;
}

