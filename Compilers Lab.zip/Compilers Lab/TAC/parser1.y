%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *ch);

int label=1;
int temp=1;

char *newtemp(){
    char temp1[20];
    sprintf(temp1,"t%d",temp++);
    return strdup(temp1);
}
char *newlabel(){
    char temp[20];
    sprintf(temp,"L%d",label++);
    return strdup(temp);
}
%}

%union{
    char *str;
}


%token <str> ID NUM
%token WHILE
%token LT ASSIGN MUL ADD
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON INVALID

%type <str> expr condition

%left ADD
%left MUL

%%

program:
        loop
        ;
loop:
        WHILE LPAREN condition RPAREN
        {
            printf("Label %d\n",label);
            printf("ifFalse %s goto label%d\n",$3,label+1);
        }
        LBRACE statements RBRACE
        {
            printf("Goto label%d\n",label);
            printf("L%d",label+1);
            label+=2;
        }
        ;

condition:
            expr LT expr
            {
                char *t=newtemp();
                printf("%s=%s<%s\n",t,$1,$3);
                $$=t;
            }
            ;

statements:
                statement
            |   statements statement
            ;

statement:
            ID ASSIGN expr SEMICOLON 
            {
                printf("%s=%s\n",$1,$3);
            }
expr:
            ID
            {
               $$=$1;
            }
            
        |
            NUM {
                $$=$1;
            }
        |
            expr ADD expr
            {
                char *temp=newtemp();
                printf("%s=%s+%s\n",temp,$1,$3);
                $$=temp;
            }
        | 
            expr MUL expr
            {
                char *temp=newtemp();
                printf("%s=%s*%s\n",temp,$1,$3);
                $$=temp;
            }
        |
            LPAREN expr RPAREN
            {
                $$ = $2;
            }
            ;


%%

void yyerror(const char *ch){
    printf("Error\n");
}
int main(){
    yyparse();
    return 0;
}