%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int yylex(void);
void yyerror(const char *s);

int temp = 1;
int label = 1;


char *newtemp()
{
    char buffer[20];
    // store the t1 in buffer
    // (destination,content,values to be replaced)
    sprintf(buffer, "t%d", temp++);
    // copies and return a pointer to the string
    //expr and condition production rules will produce str

    return strdup(buffer);
}

char *newlabel()
{
    char buffer[20];
    sprintf(buffer, "L%d", label++);
    return strdup(buffer);
}
%}

%union {
    char *str;
}

%token WHILE
%token <str> ID NUM
%token LT ASSIGN MUL ADD
%token LPAREN RPAREN LBRACE RBRACE SEMICOLON INVALID

%type <str> expr condition


%left ADD
%left MUL

%%

program:
    loop
    ;

loop:
    WHILE LPAREN condition RPAREN
    {
        printf("L%d:\n", label);
        printf("ifFalse %s goto L%d\n", $3, label + 1);
    }
    LBRACE statements RBRACE
    {
        printf("goto L%d\n", label);
        printf("L%d:\n", label + 1);
        label += 2;
    }
    ;

condition:
    expr LT expr
    {
        char *t = newtemp();
        printf("%s = %s < %s\n", t, $1, $3);
        $$ = t;
    }
    ;

statements:
    statement
    | statements statement
    ;

statement:
    ID ASSIGN expr SEMICOLON
    {
        printf("%s = %s\n", $1, $3);
    }
    ;

expr:
    ID
    {
        $$ = $1;
    }
    | NUM
    {
        $$ = $1;
    }
    | expr ADD expr
    {
        char *t = newtemp();
        printf("%s = %s + %s\n", t, $1, $3);
        $$ = t;
    }
    | expr MUL expr
    {
        char *t = newtemp();
        printf("%s = %s * %s\n", t, $1, $3);
        $$ = t;
    }
    | LPAREN expr RPAREN
    {
        $$ = $2;
    }
    ;

%%

void yyerror(const char *s)
{
    fprintf(stderr, "Syntax error: %s\n", s);
}

int main(void)
{
    printf("Three Address Code:\n");
    yyparse();
    return 0;
}